import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-left-column',
  templateUrl: './left-column.component.html',
  styleUrls: ['../login/login.component.scss'],
})
export class LeftColumnComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
