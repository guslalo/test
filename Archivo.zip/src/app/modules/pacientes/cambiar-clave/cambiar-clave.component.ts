import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cambiar-clave',
  templateUrl: './cambiar-clave.component.html',
  styleUrls: ['./cambiar-clave.component.scss'],
})
export class CambiarClaveComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
