export default {
  SAMPLE_SERVER_BASE_URL: '/',

  API_KEY: '46822534', // 46621542
};
