module.exports = {
  rootTranslationsPath: 'src/assets/i18n/',
  langs: ['es', 'pt'],
  keysManager: {},
};
